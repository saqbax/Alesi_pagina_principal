 
       <form method="post" action="registrar3.php" enctype="multipart/form-data" style="align: center">
          <div class="row form-block">
            <div class="col-lg-4">
              <h4>Aseguradora</h4>
             
            </div>
            <div class="col-lg-7 ml-auto">
              <div class="form-group"></div>
              <div class="form-group">
                <label for="form_name" class="form-label">Nombre de la Aseguradora</label>
                <input type="text" name="usr" id="form_name" class="form-control">
              </div>
              
              
              
              </div>
          <div class="row form-block flex-column flex-sm-row">
            <div class="col text-center text-sm-left">
            </div>
           <div class="col text-center text-sm-right">
            <input type="submit" class="btn btn-primary px-3" value="Enviar" required = '' >
           <!-- <a href="user-add-2.html" class="btn btn-primary px-3">
                 
                Enviar<i class="fa-chevron-right fa ml-2"></i></a> --></div> 
          </div>
        </div>
        </form>